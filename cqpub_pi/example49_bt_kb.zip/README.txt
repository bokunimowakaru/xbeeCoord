本フォルダに収録されている3つのソフトウェアに関する説明書です。
本ドキュメントの文字コードはUTF-8、改行コードは「CR+LF」です。

[example49_bt_kb]
	Bluetooth HID/SPPプロファイル搭載Keypad子機のサンプルプログラムです。
	パソコンに解凍（コピー）し、Arduino IDEの「開く」メニューから
	「example49_bt_kb.ino」を開いてください。
	※圧縮されたままだと開けないので、必ずデスクトップなどにドラッグ＆
	　ドロップなどを行い、コピーしてください。

[Adafruit_RGBLCDShield]
	Adafruit製の RGB LCD Sheild 用のライブラリです。
	Arduino IDEのライブラリフォルダにコピーしてください。

	C:\Users\ユーザ名\Documents\Arduino\libraries\

	▼ユーザ名▼マイ ドキュメント▼Arduino▼libraries

	ライセンスは、BSD Licenseに基づいて収録しています。
	詳しくは同フォルダ内のREADME.mdならびにlicense.txtにしたがって
	ください。

[LiquidCrystalDFR]
	DF ROBOT (DFR)製の LCD Keypad Shield用のライブラリです。
	Arduino IDEのライブラリフォルダにコピーしてください。
	使用する場合は「example49_bt_kb.ino」の修正が必要です。
	Adafruit用のコードを消して、DFR用に書き換えてください。
	（「example49_bt_kb.ino」内に記載）

	ライセンスは、GPL V2に基づいて収録しています。
	詳しくは同フォルダ内のREADME.txt等にしたがってください。

2016/1/24 国野亘
